># `Deployed Django Project`
>
>![image](https://github.com/imvickykumar999/DjangoWithHarry/assets/50515418/e7d1f9ab-f5d1-43da-8602-da68090530cd)
>
>      unzip /home/DjangoWithHarry/mysite/manage.zip
>
>![image](https://github.com/imvickykumar999/DjangoWithHarry/assets/50515418/2888bc55-a8b2-4555-a782-e0d1ac57869e)
>
>      zip -r mysite.zip /home/DjangoWithHarry/mysite
