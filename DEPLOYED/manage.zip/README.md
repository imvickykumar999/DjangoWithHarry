># `Deployed Django Project`
>
>![image](https://github.com/imvickykumar999/DjangoWithHarry/assets/50515418/7292d154-9c6b-44d9-9586-ba7a56dc55cd)
>
>      unzip /home/DjangoWithHarry/mysite/manage.zip
>
>![image](https://github.com/imvickykumar999/DjangoWithHarry/assets/50515418/2888bc55-a8b2-4555-a782-e0d1ac57869e)
>
>      zip -r mysite.zip /home/DjangoWithHarry/mysite
